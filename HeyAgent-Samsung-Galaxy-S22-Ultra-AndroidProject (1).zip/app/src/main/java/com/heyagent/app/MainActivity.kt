package com.heyagent.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale
import com.heyagent.app.ui.AssistantScreen
import com.heyagent.app.ui.theme.HeyAgentTheme
import com.heyagent.app.viewmodel.AssistantViewModel

/**
 * Hey Agent - Native Android Voice Assistant
 * Calibrated for Samsung Galaxy S22 Ultra (SM-S908U)
 */
class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()

    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Edge-to-edge drawing on Samsung Galaxy S22 Ultra 120Hz Dynamic AMOLED display
        enableEdgeToEdge()

        setContent {
            HeyAgentTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val micPermissionState = rememberPermissionState(
                        permission = Manifest.permission.RECORD_AUDIO
                    )

                    LaunchedEffect(Unit) {
                        if (!micPermissionState.status.isGranted) {
                            micPermissionState.launchPermissionRequest()
                        }
                    }

                    if (micPermissionState.status.shouldShowRationale) {
                        AlertDialog(
                            onDismissRequest = { /* Continue */ },
                            title = { Text("Microphone Access Needed") },
                            text = {
                                Text("Hey Agent needs microphone access to listen for the \"Hey Agent\" wake phrase and execute your spoken requests.")
                            },
                            confirmButton = {
                                Button(onClick = { micPermissionState.launchPermissionRequest() }) {
                                    Text("Grant Permission")
                                }
                            },
                            dismissButton = {
                                OutlinedButton(onClick = { /* Dismiss */ }) {
                                    Text("Not Now")
                                }
                            }
                        )
                    }

                    AssistantScreen(
                        viewModel = viewModel,
                        hasMicPermission = micPermissionState.status.isGranted,
                        onRequestMicPermission = { micPermissionState.launchPermissionRequest() }
                    )
                }
            }
        }
    }
}