package com.heyagent.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.heyagent.app.ui.components.*
import com.heyagent.app.viewmodel.AssistantViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantScreen(
    viewModel: AssistantViewModel,
    hasMicPermission: Boolean,
    onRequestMicPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()
    var inputText by remember { mutableStateOf("") }

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) listState.animateScrollToItem(uiState.messages.size - 1)
    }

    uiState.pendingSensitiveAction?.let { action ->
        SensitiveConfirmationDialog(
            action = action,
            onConfirm = { viewModel.confirmPendingAction() },
            onDismiss = { viewModel.cancelPendingAction() }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Hey Agent", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (uiState.isWakeWordActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "Wake: 'Hey Agent'",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (uiState.isWakeWordActive) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleWakeWordListening() }) {
                        Icon(if (uiState.isWakeWordActive) Icons.Filled.Hearing else Icons.Outlined.HearingDisabled, contentDescription = "Toggle Wake Word")
                    }
                    IconButton(onClick = { viewModel.clearMessages() }) {
                        Icon(Icons.Outlined.DeleteSweep, contentDescription = "Clear History")
                    }
                }
            )
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(bottom = 12.dp, top = 6.dp)) {
                if (uiState.isListening) {
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.Center) {
                        Text(uiState.interimTranscript.ifEmpty { "Listening..." }, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconButton(onClick = { viewModel.stopListening() }, enabled = uiState.isListening) {
                        Icon(Icons.Filled.StopCircle, contentDescription = "Stop", tint = if (uiState.isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    }
                    MicPulseButton(
                        isListening = uiState.isListening,
                        onStartListening = { if (hasMicPermission) viewModel.startListening() else onRequestMicPermission() },
                        onStopListening = { viewModel.stopListening() }
                    )
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Or type command...", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        trailingIcon = {
                            if (inputText.isNotEmpty()) {
                                IconButton(onClick = { viewModel.processCommand(inputText); inputText = "" }) {
                                    Icon(Icons.Filled.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { padding ->
        Column(modifier = modifier.fillMaxSize().padding(padding)) {
            val quickChips = listOf("Open Camera", "Search Google: S22 Ultra", "Open Maps", "Open Settings", "Send $50 to Alice", "Delete all contacts")
            LazyRow(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(quickChips) { chipText ->
                    val isSensitive = chipText.contains("$") || chipText.contains("Delete")
                    SuggestionChip(
                        onClick = { viewModel.processCommand(chipText) },
                        label = { Text(chipText, fontSize = 11.sp, color = if (isSensitive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface) }
                    )
                }
            }

            LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(uiState.messages, key = { it.id }) { msg ->
                    val isUser = msg.sender == "user"
                    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.widthIn(max = 300.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(msg.text, fontSize = 13.sp, color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                                msg.searchResults?.let { GoogleSearchCard(payload = it, onOpenSearchUrl = { url -> viewModel.openUrl(url) }) }
                            }
                        }
                    }
                }
            }
        }
    }
}