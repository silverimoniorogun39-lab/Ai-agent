package com.heyagent.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.heyagent.app.model.*
import com.heyagent.app.service.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class AssistantViewModel(application: Application) : AndroidViewModel(application), SpeechServiceCallbacks {
    private val _uiState = MutableStateFlow(
        AssistantUiState(
            messages = listOf(
                AssistantMessage("welcome", "agent", "Hey there! I'm Hey Agent, your native Android assistant for Samsung Galaxy S22 Ultra.\n\nSay 'Hey Agent' or tap the microphone to start!")
            )
        )
    )
    val uiState: StateFlow<AssistantUiState> = _uiState.asStateFlow()
    private var speechService: SpeechRecognitionService? = SpeechRecognitionService(application, this)

    fun startListening() {
        _uiState.value = _uiState.value.copy(isListening = true, interimTranscript = "Listening...")
        speechService?.startListening(_uiState.value.isWakeWordActive)
    }

    fun stopListening() {
        speechService?.stopListening()
        speechService?.stopSpeaking()
        _uiState.value = _uiState.value.copy(isListening = false, interimTranscript = "")
    }

    fun toggleWakeWordListening() {
        val newState = !_uiState.value.isWakeWordActive
        _uiState.value = _uiState.value.copy(isWakeWordActive = newState)
        if (newState) speechService?.startListening(true) else speechService?.stopListening()
    }

    fun processCommand(commandText: String) {
        val command = commandText.trim()
        if (command.isEmpty()) return

        val userMsg = AssistantMessage(UUID.randomUUID().toString(), "user", command)
        _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + userMsg, isListening = false, interimTranscript = "")

        val sensitive = SecurityActionGuard.checkSensitiveCommand(command)
        if (sensitive != null) {
            _uiState.value = _uiState.value.copy(pendingSensitiveAction = sensitive)
            val agentMsg = AssistantMessage(UUID.randomUUID().toString(), "agent", "⚠️ Security Warning: ${sensitive.title} requires user authorization.", sensitiveAction = sensitive)
            _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + agentMsg)
            speechService?.speak("This is a sensitive action. Please review and authorize on your screen before proceeding.")
            return
        }

        if (command.startsWith("open ", ignoreCase = true) || command.startsWith("launch ", ignoreCase = true)) {
            val query = command.replace(Regex("^(?:open|launch)\\s+", RegexOption.IGNORE_CASE), "")
            val res = AppLauncherHelper.openAppByName(getApplication(), query)
            val msg = if (res.isSuccess) "Opening ${res.label} on your Galaxy S22 Ultra..." else "Could not find app '$query'."
            _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + AssistantMessage(UUID.randomUUID().toString(), "agent", msg, appOpened = res.packageName))
            speechService?.speak(msg)
            return
        }

        if (command.startsWith("search ", ignoreCase = true) || command.startsWith("google ", ignoreCase = true)) {
            val q = command.replace(Regex("^(?:search\\s+google\\s+(?:for\\s+)?|google\\s+|search\\s+(?:for\\s+)?)", RegexOption.IGNORE_CASE), "")
            val payload = GoogleSearchPayload(q, "Found Google Search results for '$q'.", "https://www.google.com/search?q=$q")
            _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + AssistantMessage(UUID.randomUUID().toString(), "agent", "Google Search results for '$q':", searchResults = payload))
            speechService?.speak("Here are Google search results for $q.")
            return
        }

        val fallback = "Received: '$command'. Say 'Hey Agent, open Camera' or 'Hey Agent, search Google'."
        _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + AssistantMessage(UUID.randomUUID().toString(), "agent", fallback))
        speechService?.speak(fallback)
    }

    fun confirmPendingAction() {
        val action = _uiState.value.pendingSensitiveAction ?: return
        _uiState.value = _uiState.value.copy(pendingSensitiveAction = null, messages = _uiState.value.messages + AssistantMessage(UUID.randomUUID().toString(), "agent", "✅ Authorized: ${action.title} executed.", isConfirmed = true))
        speechService?.speak("Action authorized and executed.")
    }

    fun cancelPendingAction() {
        val action = _uiState.value.pendingSensitiveAction ?: return
        _uiState.value = _uiState.value.copy(pendingSensitiveAction = null, messages = _uiState.value.messages + AssistantMessage(UUID.randomUUID().toString(), "agent", "❌ Cancelled: ${action.title} rejected.", isCancelled = true))
        speechService?.speak("Action cancelled.")
    }

    fun clearMessages() { _uiState.value = _uiState.value.copy(messages = emptyList()) }
    fun openUrl(url: String) { AppLauncherHelper.openGoogleSearch(getApplication(), url) }

    override fun onReadyForSpeech() { _uiState.value = _uiState.value.copy(interimTranscript = "Listening...") }
    override fun onRmsChanged(rmsdB: Float) { _uiState.value = _uiState.value.copy(soundLevel = rmsdB) }
    override fun onInterimResult(transcript: String) { _uiState.value = _uiState.value.copy(interimTranscript = transcript) }
    override fun onFinalResult(recognizedText: String) { processCommand(recognizedText) }
    override fun onWakePhraseDetected() { speechService?.speak("Hey! How can I help you?") }
    override fun onError(errorCode: Int, errorMessage: String) { _uiState.value = _uiState.value.copy(isListening = false, interimTranscript = "") }

    override fun onCleared() {
        super.onCleared()
        speechService?.destroy()
    }
}