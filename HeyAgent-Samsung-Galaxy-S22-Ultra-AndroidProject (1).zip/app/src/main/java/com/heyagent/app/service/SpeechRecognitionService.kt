package com.heyagent.app.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale
import java.util.UUID

interface SpeechServiceCallbacks {
    fun onReadyForSpeech()
    fun onRmsChanged(rmsdB: Float)
    fun onInterimResult(transcript: String)
    fun onFinalResult(recognizedText: String)
    fun onWakePhraseDetected()
    fun onError(errorCode: Int, errorMessage: String)
}

class SpeechRecognitionService(
    private val context: Context,
    private val callbacks: SpeechServiceCallbacks
) : RecognitionListener, TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isWakeWordListening = false

    init {
        tts = TextToSpeech(context, this)
        initializeRecognizer()
    }

    private fun initializeRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@SpeechRecognitionService)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            tts?.setSpeechRate(1.02f)
        }
    }

    fun startListening(isWakeWordMode: Boolean = false) {
        if (speechRecognizer == null) initializeRecognizer()
        this.isWakeWordListening = isWakeWordMode

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        isWakeWordListening = false
        speechRecognizer?.stopListening()
    }

    fun speak(text: String) {
        val clean = text.replace(Regex("[*#_~⚠️🚨]"), "").trim()
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    override fun onReadyForSpeech(params: Bundle?) = callbacks.onReadyForSpeech()
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) = callbacks.onRmsChanged(rmsdB)
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) {
        callbacks.onError(error, "Speech recognition error: $error")
        if (isWakeWordListening) startListening(true)
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull()?.trim() ?: ""
        if (text.isNotEmpty()) {
            if (text.lowercase().contains("hey agent")) {
                callbacks.onWakePhraseDetected()
                val cmd = text.replace(Regex("(?i)^(hey|ok)\\s+agent[,\\s]*"), "").trim()
                callbacks.onFinalResult(if (cmd.isNotEmpty()) cmd else "Hey Agent")
            } else {
                callbacks.onFinalResult(text)
            }
        }
        if (isWakeWordListening) startListening(true)
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull()?.trim() ?: ""
        if (text.isNotEmpty()) {
            callbacks.onInterimResult(text)
            if (text.lowercase().contains("hey agent")) {
                callbacks.onWakePhraseDetected()
            }
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    fun destroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }
}