package com.heyagent.app.service

import com.heyagent.app.model.SensitiveAction

object SecurityActionGuard {
    fun checkSensitiveCommand(command: String): SensitiveAction? {
        val lower = command.lowercase().trim()

        if (lower.contains("send money") || lower.contains("transfer") || lower.contains("pay") ||
            lower.matches(Regex(".*(?:send|transfer|pay)\\s+\\$?\\d+.*"))) {
            return SensitiveAction(
                title = "Confirm Financial Transfer",
                description = "Hey Agent intercepted a spoken money transfer request. Outbound funds transfer requires explicit biometric or PIN authorization.",
                category = "financial",
                severity = "critical",
                parameters = mapOf(
                    "Spoken Command" to command,
                    "Security Guard" to "Samsung Knox Biometric Check",
                    "Safety Requirement" to "Never execute without user confirmation"
                )
            )
        }

        if (lower.contains("delete all") || lower.contains("delete contacts") || lower.contains("delete photos") ||
            lower.contains("wipe data") || lower.contains("erase files")) {
            return SensitiveAction(
                title = "Confirm Permanent Deletion",
                description = "You requested permanent deletion of device data. This action is irreversible.",
                category = "destructive",
                severity = "critical",
                parameters = mapOf(
                    "Action Scope" to "Permanent Device Storage Deletion",
                    "Spoken Request" to command,
                    "Safety Requirement" to "Explicit On-Screen Confirmation Required"
                )
            )
        }

        if (lower.contains("factory reset") || lower.contains("wipe phone") || lower.contains("erase everything")) {
            return SensitiveAction(
                title = "Factory Data Reset Authorization",
                description = "This action will permanently erase all accounts, media, and settings from your Samsung Galaxy S22 Ultra.",
                category = "system",
                severity = "critical",
                parameters = mapOf(
                    "Target Device" to "Samsung Galaxy S22 Ultra (SM-S908U)",
                    "Warning" to "All device partitions will be wiped",
                    "Safety Requirement" to "Explicit Confirmation Required"
                )
            )
        }

        if (lower.startsWith("send text") || lower.startsWith("send message") || lower.startsWith("send sms")) {
            return SensitiveAction(
                title = "Confirm Outbound Message",
                description = "Review and confirm message content before sending to external recipient via carrier network.",
                category = "communication",
                severity = "high",
                parameters = mapOf(
                    "Command" to command,
                    "Channel" to "Samsung Messages / SMS",
                    "Safety Requirement" to "Explicit Confirmation Required"
                )
            )
        }

        return null
    }
}