package com.heyagent.app.service

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.heyagent.app.model.AppLaunchResult

object AppLauncherHelper {
    private val KNOWN_PACKAGES = mapOf(
        "camera" to "com.sec.android.app.camera",
        "settings" to "com.android.settings",
        "chrome" to "com.android.chrome",
        "maps" to "com.google.android.apps.maps",
        "youtube" to "com.google.android.youtube",
        "messages" to "com.samsung.android.messaging",
        "phone" to "com.samsung.android.dialer",
        "gallery" to "com.sec.android.gallery3d",
        "calculator" to "com.sec.android.app.popupcalculator",
        "notes" to "com.samsung.android.app.notes",
        "spotify" to "com.spotify.music"
    )

    fun openAppByName(context: Context, appNameQuery: String): AppLaunchResult {
        val query = appNameQuery.lowercase().trim()
        val pm = context.packageManager
        val knownPkg = KNOWN_PACKAGES.entries.find { query.contains(it.key) }?.value

        val targetPackage = knownPkg ?: run {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            pm.queryIntentActivities(mainIntent, 0).find {
                val label = it.loadLabel(pm).toString().lowercase()
                label.contains(query) || query.contains(label)
            }?.activityInfo?.packageName
        }

        if (targetPackage != null) {
            val launchIntent = pm.getLaunchIntentForPackage(targetPackage)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return AppLaunchResult(true, targetPackage, query.replaceFirstChar { it.uppercase() }, "Opened $targetPackage")
            }
        }
        return AppLaunchResult(false, null, appNameQuery, "Could not find app matching '$appNameQuery'")
    }

    fun openGoogleSearch(context: Context, query: String) {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
        } else {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        }
    }
}